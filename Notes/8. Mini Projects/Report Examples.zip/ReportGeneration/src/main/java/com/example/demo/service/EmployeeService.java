package com.example.demo.service;

import java.io.IOException;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Employee;
import com.example.demo.repo.EmployeeRepo;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;

import jakarta.servlet.http.HttpServletResponse;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepo employeeRepository;

    public void generatePdfReport(HttpServletResponse response) throws IOException {
        List<Employee> employees = employeeRepository.findAll();

        response.setContentType("application/pdf");
        response.setHeader("Content-Disposition", "attachment; filename=employees_report.pdf");

        PdfWriter writer = new PdfWriter(response.getOutputStream());
        com.itextpdf.kernel.pdf.PdfDocument pdfDoc = new com.itextpdf.kernel.pdf.PdfDocument(writer);
        Document document = new Document(pdfDoc);

        document.add(new Paragraph("Employee Report"));

//        for (Employee employee : employees) {
//            document.add(new Paragraph("ID: " + employee.getId()));
//            document.add(new Paragraph("Name: " + employee.getName()));
//            document.add(new Paragraph("Position: " + employee.getPosition()));
//            document.add(new Paragraph("Salary: " + employee.getSalary()));
//            document.add(new Paragraph("\n"));
//        } // for text view
        
        
        float[] columnWidths = {100F, 100F, 100F, 100F};
        Table table = new Table(columnWidths);
        table.addCell("ID");
        table.addCell("NAME");
        table.addCell("POSITION");
        table.addCell("SALARY");
        
        for (Employee employee : employees) {
            table.addCell(String.valueOf(employee.getId()));
            table.addCell(employee.getName());
            table.addCell(employee.getPosition());
            table.addCell(String.valueOf(employee.getSalary()));
        } // for table views
        
        table.addFooterCell("YEAR-2025");
        
        document.add(table);
        document.close();
    }

    public void generateExcelReport(HttpServletResponse response) throws IOException {
        List<Employee> employees = employeeRepository.findAll();

//      response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        response.setContentType("application/octet-stream");
        response.setHeader("Content-Disposition", "attachment; filename=employees_report.xlsx");

        XSSFWorkbook workbook = new XSSFWorkbook();
        XSSFSheet sheet = workbook.createSheet("Employees");

        XSSFRow headerRow = sheet.createRow(0);
        headerRow.createCell(0).setCellValue("ID");
        headerRow.createCell(1).setCellValue("Name");
        headerRow.createCell(2).setCellValue("Position");
        headerRow.createCell(3).setCellValue("Salary");

        int rowNum = 1;
        for (Employee employee : employees) {
            XSSFRow row = sheet.createRow(rowNum++);
            row.createCell(0).setCellValue(employee.getId());
            row.createCell(1).setCellValue(employee.getName());
            row.createCell(2).setCellValue(employee.getPosition());
            row.createCell(3).setCellValue(employee.getSalary());
        }

        workbook.write(response.getOutputStream());
        workbook.close();
    }
}





//      iText 5	                    iText 7 (we are using)
//PdfWriter.getInstance(...)	  new PdfWriter(outputStream)
//Document.open()              	  Not needed – use constructor + add(...)
//Document.close()	              Still valid and needed
