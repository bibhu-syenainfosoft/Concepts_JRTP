package com.example.demo.controller;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.example.demo.model.Employee;
import com.example.demo.repo.EmployeeRepo;

//@Component
public class DataInsertRunner implements CommandLineRunner {

	@Autowired
	private EmployeeRepo repo;
	
	@Override
	public void run(String... args) throws Exception {
		
		Employee emp1 = new Employee();
		emp1.setName("Bibhu");
		emp1.setPosition("Developer");
		emp1.setSalary(22600.00);
		
		Employee emp2 = new Employee();
		emp2.setName("Kamal");
		emp2.setPosition("Tester");
		emp2.setSalary(20100.00);
		
		Employee emp3 = new Employee();
		emp3.setName("Rahul");
		emp3.setPosition("Business Analyst");
		emp3.setSalary(34500.00);
		
		repo.saveAll(Arrays.asList(emp1,emp2,emp3));
	}

}
