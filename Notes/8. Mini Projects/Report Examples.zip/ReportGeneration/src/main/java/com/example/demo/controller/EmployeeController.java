package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.service.EmployeeService;

import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@RestController
@RequestMapping("/reports")
public class EmployeeController {

    @Autowired
    private EmployeeService reportService;

    @GetMapping("/pdf")
    public void getPdfReport(HttpServletResponse response) throws IOException {
        try {
            reportService.generatePdfReport(response);
        } catch (Exception e) {
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error generating PDF report");
        }
    }

    @GetMapping("/excel")
    public void getExcelReport(HttpServletResponse response) throws IOException {
        try {
            reportService.generateExcelReport(response);
        } catch (Exception e) {
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error generating Excel report");
        }
    }
}
